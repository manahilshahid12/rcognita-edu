import pandas as pd
import matplotlib.pyplot as plt

# List of file paths
file_paths = [f'Exp#{i:02d}.csv' for i in range(1, 10)]

# List of metadata information corresponding to each experiment
metadata_info_list = [
    """
    System: 3wrobotNI
    Controller: N_CTRL
    dt: 0.1
    state_init: [-3, -3, 1.57]
    Nactor: 6
    pred_step_size_multiplier: 5.0
    buffer_size: 25
    run_obj_struct: quadratic
    R1_diag: [100, 100, 10, 0, 0]
    R2_diag: [1, 10, 1, 0, 0]
    Ncritic: 25
    gamma: 0.9
    critic_period_multiplier: 1.0
    critic_struct: quad-mix
    actor_struct: quad-nomix
    """,
    """
    System: 3wrobotNI
    Controller: N_CTRL
    dt: 0.1
    state_init: [-2, -2, 1.57]
    Nactor: 6
    pred_step_size_multiplier: 5.0
    buffer_size: 25
    run_obj_struct: linear
    R1_diag: [50, 50, 5, 0, 0]
    R2_diag: [0.5, 5, 0.5, 0, 0]
    Ncritic: 25
    gamma: 0.9
    critic_period_multiplier: 1.0
    critic_struct: quad-nomix
    actor_struct: quad-nomix
    """,
    """
    System,3wrobotNI
    Controller,N_CTRL
    dt,0.1
    state_init,[-3.   -3.    1.57]
    Nactor,6
    pred_step_size_multiplier,5.0
    buffer_size,25
    run_obj_struct,quadratic
    R1_diag,"[100, 100, 10, 0, 0]"
    R2_diag,"[1, 10, 1, 0, 0]"
    Ncritic,25
    gamma,0.9
    critic_period_multiplier,1.0
    critic_struct,quad-mix
    actor_struct,quad-nomix
    """,
    """
    System,3wrobotNI
    Controller,N_CTRL
    dt,0.1
    state_init,[-3.   -3.    1.57]
    Nactor,6
    pred_step_size_multiplier,5.0
    buffer_size,25
    run_obj_struct,quadratic
    R1_diag,"[100, 100, 10, 0, 0]"
    R2_diag,"[1, 10, 1, 0, 0]"
    Ncritic,25
    gamma,0.9
    critic_period_multiplier,1.0
    critic_struct,quad-mix
    actor_struct,quad-nomix
    """,
    """
    System,3wrobotNI
    Controller,N_CTRL
    dt,0.1
    state_init,[-3.   -3.    1.57]
    Nactor,6
    pred_step_size_multiplier,5.0
    buffer_size,25
    run_obj_struct,quadratic
    R1_diag,"[100, 100, 10, 0, 0]"
    R2_diag,"[1, 10, 1, 0, 0]"
    Ncritic,25
    gamma,0.9
    critic_period_multiplier,1.0
    critic_struct,quad-mix
    actor_struct,quad-nomix
    """,
    """
    System,3wrobotNI
    Controller,N_CTRL
    dt,0.1
    state_init,[-3.   -3.    1.57]
    Nactor,6
    pred_step_size_multiplier,5.0
    buffer_size,25
    run_obj_struct,quadratic
    R1_diag,"[100, 100, 10, 0, 0]"
    R2_diag,"[1, 10, 1, 0, 0]"
    Ncritic,25
    gamma,0.9
    critic_period_multiplier,1.0
    critic_struct,quad-mix
    actor_struct,quad-nomix
    """,
    """
    System,3wrobotNI
    Controller,N_CTRL
    dt,0.1
    state_init,[-1.   -1.    1.04]
    Nactor,6
    pred_step_size_multiplier,5.0
    buffer_size,25
    run_obj_struct,quadratic
    R1_diag,"[100, 100, 10, 0, 0]"
    R2_diag,"[1, 10, 1, 0, 0]"
    Ncritic,25
    gamma,0.9
    critic_period_multiplier,1.0
    critic_struct,quad-mix
    actor_struct,quad-nomix
    """,
    """
    System,3wrobotNI
    Controller,N_CTRL
    dt,0.1
    state_init,[-5.  -5.   0.5]
    Nactor,6
    pred_step_size_multiplier,5.0
    buffer_size,25
    run_obj_struct,quadratic
    R1_diag,"[100, 100, 10, 0, 0]"
    R2_diag,"[1, 10, 1, 0, 0]"
    Ncritic,25
    gamma,0.9
    critic_period_multiplier,1.0
    critic_struct,quad-mix
    actor_struct,quad-nomix
    """,
    """
    System,3wrobotNI
    Controller,N_CTRL
    dt,0.1
    state_init,[-7.   -7.    2.09]
    Nactor,6
    pred_step_size_multiplier,5.0
    buffer_size,25
    run_obj_struct,quadratic
    R1_diag,"[100, 100, 10, 0, 0]"
    R2_diag,"[1, 10, 1, 0, 0]"
    Ncritic,25
    gamma,0.9
    critic_period_multiplier,1.0
    critic_struct,quad-mix
    actor_struct,quad-nomix
    """,
    """
    System,3wrobotNI
    Controller,N_CTRL
    dt,0.1
    state_init,[-10.  -10.    2.6]
    Nactor,6
    pred_step_size_multiplier,5.0
    buffer_size,25
    run_obj_struct,quadratic
    R1_diag,"[100, 100, 10, 0, 0]"
    R2_diag,"[1, 10, 1, 0, 0]"
    Ncritic,25
    gamma,0.9
    critic_period_multiplier,1.0
    critic_struct,quad-mix
    actor_struct,quad-nomix
    """
]

# Loop through each file path and corresponding metadata
for i, file_path in enumerate(file_paths):
    # Load the data
    data = pd.read_csv(file_path, skiprows=15)

    # Extract the relevant columns
    time = data['t [s]']
    velocity = data['v [m/s]']

    # Plotting
    plt.figure(figsize=(14, 6))
    plt.plot(time, velocity, label=f'Experiment {i+1}', color='blue')

    # Adding title and labels
    plt.title(f'Velocity vs. Time - Experiment {i+1}')
    plt.xlabel('Time (s)')
    plt.ylabel('Velocity (m/s)')
    plt.legend()

    # Adding metadata as text to the right side of the plot
    plt.text(1.02, 0.5, metadata_info_list[i], transform=plt.gca().transAxes, fontsize=10, 
             verticalalignment='center', bbox=dict(facecolor='white', alpha=0.5))

    # Adjust the plot to make room for the text
    plt.subplots_adjust(right=0.8)

    # Display the plot
    plt.grid(True)
    plt.show()
